module.exports = test => test.replace(/^test[/\\]/, 'lib/')
